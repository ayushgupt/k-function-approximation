# include <stdio.h>
# include <stdlib.h>
# include <math.h>



int main()
{
	printf("1\n");
	printf("-100 10\n");
	return 0;
}
