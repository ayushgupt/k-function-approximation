#include <bits/stdc++.h>
using namespace std;
int main(int argc, char* argv[])
{
	cout<<"1"<<endl;
	cout<<"-100 10"<<endl;
    return 0;
}