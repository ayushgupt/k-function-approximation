import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class stepDp 
{

    public static void main(String[] args)
    {
	        		System.out.println("1");
	        		System.out.println("-100 10");
	}
}